import React from 'react'
import {NavLink}  from 'react-router-dom'
import './FootNavigation.styl'

export default class  extends React.Component{
    render(){
        return(
            <div className="footernav">
                <NavLink to='/homepage' className="guide_item" >
      <span className="item_icon">
        <i className="iconfont icon-wxbmingxingdianpu"></i>
      </span>
                <span>主页</span>
            </NavLink>
        <NavLink to='/classify' className="guide_item">
        <span className="item_icon">
        <i className="iconfont icon-icon04"></i>
          </span>
            <span>分类</span>
        </NavLink>
        <NavLink to='/shoppingcart' className="guide_item">
        <span className="item_icon">
        <i className="iconfont icon-gouwuche"></i>
      </span>
        <span>购物车</span>
    </NavLink>
        <NavLink to='/myself' className="guide_item">
        <span className="item_icon">
        <i className="iconfont icon-xiaolian"></i>
      </span>
        <span>我的E宠</span>
    </NavLink>
    </div>
        )
    }
}