import React from 'react'

export default class Myself extends React.Component{
    render(){
        return(
            <div>
                Myself
            </div>
        )
    }
}