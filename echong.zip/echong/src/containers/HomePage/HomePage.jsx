import React from 'react'
import './HomePage.styl'
import FootNavigation from '../../commonents/FootNavigation/FootNavigation'
export default class HomePage extends React.Component{
    render(){
        return(
            <div>
                <header className="headerbox" id="header">
                    <div className="xiazaiApp" >
                        <span className="clsoebtn">
                        <img src="//static.epetbar.com/static_wap/lib/common_images/closebtn_03.png" alt=""/>
                        </span>
                        <a href="">
                            <img src="https://img2.epetbar.com/nowater/2017-12/13/18/c63b6e6cf483cbb61196f658920a9d6e.jpg@!water" alt=""/>
                        </a>
                    </div>
                    <div className="headerMain">
                        <div className="headerTop">
                            <div className="leftInfo">
                                <a href="javascript:;">
                                    <span>狗狗</span>
                                    <span className="xian">|</span>
                                    <span className="samll">重庆</span>
                                    <i></i>
                                </a>
                            </div>
                            <p className="search-text">
                                <a href="javascript:;">
                                    <input className="search-input" placeholder="搜索商品和品牌" disabled="disabled" />
                                    <span className="iconfont icon-sousuo serach-ico"></span>
                                </a>
                            </p>
                            <img src="//static.epetbar.com/static_web/wap/src/images/mydope.png"/>
                        </div>
                    </div>
                    <div className="find_nav">
                        <div className="proceedVessel">
                            <div className="find_nav_list">
                                <ul className="menu-wrapper">
                                    <li>
                                    <a href="">
                  <span>
                    <span></span>
                    <i></i>
                  </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
            </div>
    </header>
        <div className="main" id="main">
            {/*<imageCarousel />*/}
        <div>
            <div className="columnnavdiv">
                <ul>
                    <li >
                    <a href="javascript:;">
                        <img src=''/>
                    </a>
                </li>
            </ul>
        </div>
    </div>
        <div>
            <div className="banner_item">
                <a href="">
                    <img src="https://img2.epetbar.com/nowater/2017-12/18/09/60c354a5d94be9fd114523ee77259c73.gif" alt=""/>          </a>
            </div>
        </div>
        <div>
            <div className="surprise_day">
                <div className="surprise">
                    <div className="surprise-tit">
                        <div className="titimg">
                            <img src="" alt=""/>
                        </div>
                        <div className="nexttip"></div>
                        <div className="time">
                            <div className="timeWrap">
                                <span></span>
                            </div>
                        </div>
                        <div className="more">
                            <a href="">
                                <img src="" alt=""/>
                            </a>
                        </div>
                    </div>
                    <div className="surprise-pro">
                        <div className="swiper-container surpriseSwiper">
                            <div className="swiper-wrapper">
                                <div className="swiper-slide" v-for="(cd , index) in maincarousel.data[3].goods">
                                    <div className="pro-block">
                                        <a href="">
                                            <div className="imgWrap">
                                                <img src="" alt=""/>
                                            </div>
                                            <div className="cred">
                                                <span></span>
                                            </div>
                                            <p></p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div>
        </div>
        <div>
            <div className="currency_ad" v-if="mainData.datas">
                <div className="currency_ad_l">
                    <a href="">
                        <img src="" alt=""/>
                    </a>
                </div>
                <div className="currency_ad_r">
                    <a href="">
                    <img src="" alt=""/>
                </a>

            </div>
        </div>
    </div>
        <div>

        </div>
        <div v-if="mainData.datas">
            <div className="banner_item" >
                <a href="">
                    <img src="" alt=""/></a>
            </div>
        </div>
        
       
      
        <div className="footer">
            <div className="footerTop">
                <span className="on">触屏版</span>
                <span>手机客户端</span>
                <span>关于我们</span>
                <span>联系我们</span>
            </div>
            <div className="footerBottom">
                © wap.epet.com 版权：重庆易宠科技有限公司
            </div>
        </div>




        <FootNavigation/>
            </div>
            </div>
        )
    }
}
