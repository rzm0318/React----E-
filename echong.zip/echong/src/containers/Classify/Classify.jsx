import React from 'react'
import FootNavigation from '../../commonents/FootNavigation/FootNavigation'
export default class  Classify extends React.Component{
    render(){
        return(
            <div>
                Classify
                <FootNavigation/>
            </div>
        )
    }
}