import React from 'react'

export default class ShoppingCart extends React.Component{
    render(){
        return(
            <div>
                ShoppingCart
            </div>
        )
    }
}