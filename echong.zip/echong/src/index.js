import React from 'react';
import ReactDOM from 'react-dom';
import './untils/css/reset.css'
import {BrowserRouter,Switch,Route} from 'react-router-dom'
import FootNavigation from './commonents/FootNavigation/FootNavigation';
import registerServiceWorker from './registerServiceWorker';


import HomePage from  './containers/HomePage/HomePage'
import Classify from  './containers/Classify/Classify'
import Myself from  './containers/Myself/Myself'
import ShoppingCart from  './containers/ShoppingCart/ShoppingCart'

ReactDOM.render((
    <BrowserRouter>
        <Switch>

            <Route path='/classify' component={Classify}/>
            <Route path='/myself' component={Myself}/>
            <Route path='/shoppingcart' component={ShoppingCart}/>
            <Route component={HomePage}/>
        </Switch>
    </BrowserRouter>
), document.getElementById('root'));
registerServiceWorker();
